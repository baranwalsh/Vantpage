import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../supabase/client';

const LandingPage = () => {
  const navigate = useNavigate();

  // Redirect if user is logged in
  useEffect(() => {
    const checkSession = async () => {
      const { data } = await supabase.auth.getSession();
      if (data.session) navigate('/app');
    };
    checkSession();
  }, []);

  // OS Detection for Download Button
  const getOS = () => {
    const userAgent = window.navigator.userAgent;
    if (userAgent.includes("Win")) return "Windows";
    if (userAgent.includes("Mac")) return "macOS";
    return "Web";
  };

  return (
    <div className="landing-page">
      {/* Animated Light Background */}
      <div className="light-effect" />

      {/* Content */}
      <div className="content">
        <h1 className="text-glow">GlassWriter</h1>
        <p className="subtitle">Notion-like editor with mind maps, backlinks, and rainbow glass design</p>

        {/* Download/Button */}
        <div className="cta">
          <button 
            className="glass-button primary"
            onClick={() => {
              const os = getOS();
              if (os === "Windows") window.location.href = "/download/windows";
              else if (os === "macOS") window.location.href = "/download/macos";
              else navigate('/app');
            }}
          >
            {getOS() === "Web" ? "Launch Web App" : `Download for ${getOS()}`}
          </button>
        </div>

        {/* Features Table */}
        <div className="features">
          <div className="feature-item">
            <span>✨</span>
            <h3>Backlinks</h3>
            <p>Automatic wikilink detection between documents</p>
          </div>
          <div className="feature-item">
            <span>🗂️</span>
            <h3>Folders</h3>
            <p>Infinite nested folders and Kanban boards</p>
          </div>
          <div className="feature-item">
            <span>🎨</span>
            <h3>Glass Design</h3>
            <p>Rainbow glassmorphism and dark mode</p>
          </div>
        </div>

        {/* Footer */}
        <div className="footer">
          <p>Free forever • Developed by Shagun B.</p>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;