import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.https://mjjvyhmedgsqpqoamtxj.supabase.co;
const supabaseKey = import.meta.env.eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1qanZ5aG1lZGdzcXBxb2FtdHhqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE1MDgzMTcsImV4cCI6MjA1NzA4NDMxN30.rJ_UZf-7GRbOGzwwkDmRz1CmBeC-pnDPl7aQwYulWTQ;

export const supabase = createClient(supabaseUrl, supabaseKey);